# PyTorch Grokking Experiment Report

## Overview
- **Experiment ID**: `exp_1785406284582_p113`
- **ML Core Engine**: `pytorch_core`
- **Artifact Source**: `REAL_PYTORCH_RUN`
- **Status**: **COMPLETED**
- **Status Classifier**: `GROKKING_CONFIRMED`
- **Steps Completed**: `40000 / 40000`

## Hyperparameters & Configuration
- **Dataset Prime (p)**: `113` (`target = (a + b) mod 113`)
- **Model Type**: `transformer_1layer`
- **Architecture**: `transformer_1layer`
- **Architecture Version**: `canonical_v1`
- **Vocab Size**: `114`
- **d_model**: `128`
- **hidden_size**: `None`
- **d_mlp**: `512`
- **n_heads**: `4`
- **n_layers**: `1`
- **Context Length**: `3`
- **Tokenization Spec**: `[a, b, EQUALS] with EQUALS token id p and vocab_size p + 1`
- **Prediction Position**: `last`
- **Dropout**: `0.0`
- **Normalization Type**: `none`
- **Activation**: `relu`
- **Attention Mask**: `causal`
- **Train Split**: `0.3`
- **Seed**: `43`
- **Optimizer**: `AdamW (lr=0.001, weight_decay=1.0)`
- **Log Interval**: `100`
- **Metric Log Interval**: `100`
- **Memorization Check Interval**: `1`
- **Generalization Check Interval**: `100`
- **Full Batch**: `True`

## Final Training Metrics
- **Train Accuracy**: `1.0000` (100.00%)
- **Validation Accuracy**: `1.0000` (100.00%)
- **Train Loss**: `0.001002`
- **Validation Loss**: `0.002267`
- **Weight Norm ($||W||_2$)**: `46.2821`

## Grokking Event Milestones
- **Memorization Step (Train Acc >= 0.98)**: `302`
- **Candidate Grokking Step (Val Acc >= 0.985)**: `32300`
- **Plateau Step (`stability_checks` consecutive checks >= 0.985)**: `33200`
- **event_detection_resolution**: `memorization checked every optimizer step; generalization checked every 100 optimizer step(s)`
- **generalization_check_interval**: `100`
- **stability_checks**: `10`
- **stability_span_steps**: `900`
- **last_below_threshold**: step `301`, train_accuracy `0.9791122674942017`
- **first_at_or_above_threshold**: step `302`, train_accuracy `0.980156660079956`

## Saved PyTorch Checkpoints
| Checkpoint Name | Format | Step | Role | Replayed Train Acc | Replayed Val Acc | SHA-256 |
|---|---|---|---|---|---|---|
| `init_model_state.pt` | `pt` | 0 | `INIT_BEFORE_TRAINING` | 0.0097 | 0.0087 | `346299506ae3e101...` |
| `memorization_model_state.pt` | `pt` | 302 | `MEMORIZATION` | 0.9802 | 0.0027 | `6d9b16726f5d627d...` |
| `threshold_98_5_model_state.pt` | `pt` | 32300 | `GROKKING_CANDIDATE` | 1.0000 | 0.9900 | `1a63e11386a6102e...` |
| `plateau_model_state.pt` | `pt` | 33200 | `PLATEAU` | 1.0000 | 1.0000 | `45f3670d0dc1bc8d...` |
| `final_model_state.pt` | `pt` | 40000 | `FINAL_MODEL_STATE` | 1.0000 | 1.0000 | `bfab3506e475dfbc...` |

## Grokking Claim Authenticity Audit
- **authenticity_status**: `PASS`
- **baseline_check**: `PASS`
- **manifest_check**: `PASS`
- **timeseries_check**: `PASS`
- **checkpoint_replay_check**: `PASS`
- **no_fake_metrics_check**: `PASS`
- **architecture_contract_check**: `PASS`
- **config_manifest_checkpoint_parity**: `PASS`
- **tokenization_round_trip_check**: `PASS`
- **replay_max_abs_diff**: `0.0`
- **has_layernorm**: `False`
- **final_scientific_status**: `VERIFIED_SINGLE_RUN_GROKKING`

## Conclusion & Limitations
This PyTorch run serves as the reference benchmark to evaluate whether grokking (delayed generalization) occurs under standard float32 PyTorch training dynamics.
A single experiment run does not prove or disprove general grokking mechanisms across all hyperparameter regimes.
