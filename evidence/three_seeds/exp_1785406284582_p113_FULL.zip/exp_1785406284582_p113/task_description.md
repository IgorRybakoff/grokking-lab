model_type = transformer_1layer
p = 113
train_split = 0.3
seed = 43

d_model = 128
n_heads = 4
d_mlp = 512

training_steps = 40000
log_interval = 100

learning_rate = 0.001
weight_decay = 1.0
threshold_accuracy = 0.985
threshold_stability = 10