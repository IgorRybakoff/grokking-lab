# PyTorch Grokking Experiment Report

## Overview
- **Experiment ID**: `exp_p113_seed44_research_v04`
- **ML Core Engine**: `pytorch_core`
- **Artifact Source**: `REAL_PYTORCH_RUN`
- **Mode**: `research_run`
- **Status**: **COMPLETED**
- **Status Classifier**: `GROKKING_CONFIRMED`
- **Steps Completed**: `40000 / 40000`

## Hyperparameters & Configuration
- **Dataset Prime (p)**: `113` (`target = (a + b) mod 113`)
- **Model Type**: `transformer_1layer`
- **Architecture**: `transformer_1layer`
- **Architecture Version**: `canonical_v1`
- **Vocab Size**: `114`
- **d_model**: `128`
- **hidden_size**: `None`
- **d_mlp**: `512`
- **n_heads**: `4`
- **n_layers**: `1`
- **Context Length**: `3`
- **Tokenization Spec**: `[a, b, EQUALS] with EQUALS token id p and vocab_size p + 1`
- **Prediction Position**: `last`
- **Dropout**: `0.0`
- **Normalization Type**: `none`
- **Activation**: `relu`
- **Attention Mask**: `causal`
- **Train Split**: `0.3`
- **Seed**: `44`
- **Optimizer**: `AdamW (lr=0.001, weight_decay=1.0)`
- **Log Interval**: `100`
- **Metric Log Interval**: `100`
- **Memorization Check Interval**: `1`
- **Generalization Check Interval**: `100`
- **Full Batch**: `True`
- **Source Freeze Status**: `PASS`
- **Source Hash Manifest SHA-256**: `ff07a10571a192c94ed1be703c0c2301b7813e48c5375882d9a5a02ba5b643c4`
- **Dataset Split Hash**: `94167ae106ecee497af3df20a77bc56d2659fe15dc026a7df82cb4e420867579`
- **Environment Lock Hash**: `e86aa366604114af1532a4fe501e062591876d0a832717c489dcab8bfb5ee2bc`

## Final Training Metrics
- **Train Accuracy**: `1.0000` (100.00%)
- **Validation Accuracy**: `1.0000` (100.00%)
- **Train Loss**: `0.000218`
- **Validation Loss**: `0.000470`
- **Weight Norm ($||W||_2$)**: `48.1401`

## Grokking Event Milestones
- **Memorization Step (Train Acc >= 0.98)**: `416`
- **Candidate Grokking Step (Val Acc >= 0.985)**: `23000`
- **Plateau Step (`stability_checks` consecutive checks >= 0.985)**: `23900`
- **event_detection_resolution**: `memorization checked every optimizer step; generalization checked every 100 optimizer step(s)`
- **generalization_check_interval**: `100`
- **stability_checks**: `10`
- **stability_span_steps**: `900`
- **last_below_threshold**: step `415`, train_accuracy `0.9791122674942017`
- **first_at_or_above_threshold**: step `416`, train_accuracy `0.980156660079956`

## Saved PyTorch Checkpoints
| Checkpoint Name | Format | Step | Role | Replayed Train Acc | Replayed Val Acc | SHA-256 |
|---|---|---|---|---|---|---|
| `init_model_state.pt` | `pt` | 0 | `INIT_BEFORE_TRAINING` | 0.0065 | 0.0098 | `870fb3fea3cf79ab...` |
| `memorization_model_state.pt` | `pt` | 416 | `MEMORIZATION` | 0.9802 | 0.0016 | `6a70d6cfd007505a...` |
| `threshold_98_5_model_state.pt` | `pt` | 23000 | `GROKKING_CANDIDATE` | 1.0000 | 0.9851 | `bc08d63442851291...` |
| `plateau_model_state.pt` | `pt` | 23900 | `PLATEAU` | 1.0000 | 0.9998 | `2d47d34aa7c446a3...` |
| `final_model_state.pt` | `pt` | 40000 | `FINAL_MODEL_STATE` | 1.0000 | 1.0000 | `a8899247a5d5483b...` |

## Grokking Claim Authenticity Audit
- **authenticity_status**: `PASS`
- **baseline_check**: `PASS`
- **manifest_check**: `PASS`
- **source_freeze_check**: `PASS`
- **environment_check**: `PASS`
- **dataset_split_check**: `PASS`
- **timeseries_check**: `PASS`
- **checkpoint_replay_check**: `PASS`
- **no_fake_metrics_check**: `PASS`
- **architecture_contract_check**: `PASS`
- **config_manifest_checkpoint_parity**: `PASS`
- **tokenization_round_trip_check**: `PASS`
- **replay_max_abs_diff**: `0.0`
- **has_layernorm**: `False`
- **final_scientific_status**: `VERIFIED_SINGLE_RUN_GROKKING`

## Conclusion & Limitations
This PyTorch run serves as the reference benchmark to evaluate whether grokking (delayed generalization) occurs under standard float32 PyTorch training dynamics.
A single experiment run does not prove or disprove general grokking mechanisms across all hyperparameter regimes.
